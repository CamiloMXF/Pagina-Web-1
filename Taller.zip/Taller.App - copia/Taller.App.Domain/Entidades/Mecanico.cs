using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Taller.App.Domain
{
    public class Mecanico : Persona
    {
        String Direccion { get; set;}
        String NivelEstudio { get; set;}
        

    }
}