﻿namespace Taller.App.Domain;
public class Class1
{

}
