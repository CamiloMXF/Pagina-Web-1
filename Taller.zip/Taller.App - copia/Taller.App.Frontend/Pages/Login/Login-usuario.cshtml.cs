using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Taller.App.Frontend.Pages
{
    public class Login_usuarioModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
