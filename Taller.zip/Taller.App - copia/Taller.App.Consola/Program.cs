﻿using System;

namespace Taller.App.Consola {


    class program {

        static void Main(string[] args) {
            
        }

    }
}

